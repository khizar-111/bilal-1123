// +build !arm

package settings

var playstationCore = "swanstation_libretro"
