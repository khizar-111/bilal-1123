package settings

var playstationCore = "pcsx_rearmed_libretro"
